from tensorflow.python.keras.preprocessing.sequence import pad_sequences
from tensorflow.python.keras.preprocessing.text import Tokenizer
import numpy as np

#from app.main.utils import logger
import helper
import constants
#import trainer


def predict_intent(utterance):
    # import nlu settings

    min_confidence = constants.THRASHOLD

    max_length = 10
    glove_dimension = 100
    #logger.info('Start intent classification')
    glove_path = constants.GLOVE_PATH
    verbose = constants.VERBOSE

    # prepare test data ----------------------------------------------
    word_index, classes, embed_matrix = helper.get_token_data()

    tk = Tokenizer()

    tk.word_index = word_index

    x_test = tk.texts_to_sequences([utterance])
    x_test = pad_sequences(x_test, maxlen=max_length, padding='post')

    # get trained model ----------------------------------------------
    # glove_dict = helper.generate_glove_dict(glove_path)
    vocab_size = len(tk.word_index) + 1
    # embed_matrix = helper.get_embedding_matrix(glove_dict, tk.word_index.items(), vocab_size, glove_dimension)
    model = helper.get_glove_model(vocab_size, glove_dimension, embed_matrix, max_length, len(classes))

    model = helper.load_nlp_model_weights(model)
    # predict --------------------------------------------------------
    prediction = model.predict(x_test, verbose=verbose)

    predicted_class = helper.get_predicted_class(min_confidence, prediction, classes)

    return predicted_class


# TODO: apply thrashold
def predict_action(domain_tokens, maxlen, num_features, sequence):
    #logger.info('================>>>>>>>>>>>>>>>> START DIALOG FLOW PREDICTION <<<<<<<<<<<<<<<<<=============')
    try:
        class_predicted = None
        min_confidence = constants.THRASHOLD
        # prepare test data
        x_test = np.array(sequence)
        x_test = pad_sequences([x_test],  maxlen=maxlen, padding='post')

        # get model
        model = helper.create_dialog_network(maxlen, len(domain_tokens))

        # load weights
        model = helper.load_dm_model_weights(model)

        # reset model states
        # model.reset_states()
        print('X_test: ', x_test)

        pred = model.predict(x_test, verbose=1)

        # get max score class
        max_score_index = np.argmax(pred)

        # log data predicted
        for key, val in domain_tokens.items():
            if val == max_score_index:
                class_predicted = key
                break
        #logger.info('predicted------->>>>>>>, {}'.format(class_predicted))

        return max_score_index
    except Exception as err:
        #logger.error(err)
        raise err


def restart_predictor():
    helper.clear_prediction_data()

user_id=1
try:
        domain_tokens, maxlen, num_features = helper.get_dialog_options()

        print(domain_tokens)
        # get user intent
        prediction = predict_intent("")
        #logger.info('Predicted intent token:{}'.format(prediction))

        if prediction is None:
            text_response = helper.generate_utter('utter_repeat_again')
        else:
            utterance_token = domain_tokens[prediction]

            # get dialog state
            state = helper.get_dialog_state()

            if state is not None:
                pass
            else:
                state = dict({user_id: []})

            # generate x_test for DM prediction/ restore dialog state
            x_test = state[user_id]
            #x_test=[]
            # update user dialog state with new utterance
            x_test.append(utterance_token)

            # get lats n-actions with dialog length dimension
            if len(x_test) > maxlen:
                x_test = x_test[-maxlen:]

            # predict next action
            print('actions before predict:', x_test)
            action_predicted = predict_action(domain_tokens, maxlen, num_features, x_test)

            if action_predicted is not None:
                # save max length+1 actions
                x_test.append(action_predicted)

            #logger.info(
             #   'PREDICTED ACTION: {} with index {}'.format(get_key(domain_tokens, action_predicted), action_predicted))
            text_response = helper.get_utterance(domain_tokens, action_predicted)

            print('actions after predict:', x_test)
            # save chat state
            state[user_id] = x_test
            print(x_test)
            helper.save_dialog_state(state)

        #bot_response['text'] = text_response
        print(text_response)
        
except Exception as err:
    raise err
        
'''   
predicted_class = predict_intent("Can you help me?")
seq= list(predicted_class)
try:
    domain_tokens, maxlen, num_features= helper.get_dialog_options()
    seq = trainer.tokenize_matrix(seq, tokens=domain_tokens)
    predict_action(domain_tokens, maxlen, num_features,seq)
except Exception as err:
    raise err
'''