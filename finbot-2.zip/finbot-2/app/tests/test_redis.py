import unittest


class RedisTests(unittest.TestCase):
    # TODO: create tests for redis connecion
    pass
